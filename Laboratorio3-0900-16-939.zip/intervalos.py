def intervalo(num1, num2, num3):
    if (num1 < num2 < num3):
        print(True)
    else:
        print(False)

intervalo(0, 11, 10)
intervalo(0, 5, 10)